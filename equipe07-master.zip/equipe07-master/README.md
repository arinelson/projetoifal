# equipe07
Equipe 07 - Audiovisual

 - Julio Cesar Tavares [] --Falta adicionar ao canal do Slack
 - José Carlos [carlinhosacioali@gmail.com]
 - Tais Araujo [emmearaujo@gmail.com]
 - Arinelson [arinelson_hermano@hotmail.com]
